<?php 
$objetoMysqli = new mysqli(localhost, nomUsuario, contraseña, nombreBd);
define("DB_HOST","ipServidor" ); 
define("DB_USER", "nomUsuario"); 
define("DB_PASS", "contraseña"); 
define("DB_DATABASE", "nombreBd" ); 
$objetoMysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_DATABASE);
if ($objetoMysqli -> connect_errno){
    die("Error de conexión: " . $objetoMysqli->mysqli_connect_errno() . ", " . $objetoMysqli->mysqli_connect_error()); 
}
else{
    echo "La conexión tuvo éxito";
}
$objetoMysqli->mysqli_close();
 ?>